## 🏄 Installation

  1. Clone/Download the repo.
  2. Run npm install.
  3. Config the BackEnd FireBase Change the values in src/firebase/config.js to suit your firebase console project api key values.
  4. Run npm start to spin the up the local dev server port 3000.(http://localhost:3000).
